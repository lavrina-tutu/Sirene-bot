---
name: contact-resolution
description: "Resolve person mentions (aliases, nicknames, logins) to canonical contact records in WorkVault Markdown tables."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [contacts, aliases, obsidian, name-resolution, tutu]
---

# Contact Resolution

Resolves free-form person references ("Саша", "Иванов", "a.ivanov") to canonical rows in the WorkVault contact tables.

## Источник контактов

`C:\\Users\\tkachenkoav\\WorkVault\\Contacts\\contacts.enc` — единый зашифрованный справочник (AnywhereContacts, schema v2). Источники: Exchange GAL + Zulip. Первичный ключ — `login` (часть email до @).

Старые Markdown-файлы (`tutu-contacts.md`, `external-contacts.md`) — **устарели, не использовать**.

## ⚠️ PII Masking при выводе пользователю (КРИТИЧНО)

Все данные контакта (ФИО, email, login, telegram) — PII. Перед **любым** выводом пользователю вызывать `mask_contact`:

```python
from anywhere_contacts import mask_contact
hits_for_display = {k: mask_contact(v) for k, v in hits.items()}
# показывать только hits_for_display
```

Правильно: `Кр**в Ки**л`, `kr**v@tutu.ru`
Неправильно: `Криворотов Кирилл`, `krivorotov@tutu.ru`

Сырые данные допустимы только внутри инструментов (запись в Jira, Confluence) — не в чате.

## Resolution Steps

1. Взять строку упоминания как есть.
2. Поискать через Python:
```python
import sys
sys.path.insert(0, 'C:/Users/tkachenkoav/Documents/Cursor_projects/hermes-agent/USERTOOLS/AnywhereContacts')
from anywhere_contacts.store import create_store
from pathlib import Path
import os
from dotenv import load_dotenv
load_dotenv('C:/Users/tkachenkoav/Documents/Cursor_projects/hermes-agent/USERTOOLS/MoveFromExchange/.env')
store = create_store(
    Path('C:/Users/tkachenkoav/WorkVault/Contacts/contacts.enc'),
    os.environ['CONTACTS_ENCRYPTION_KEY']
)
data = store.read()
contacts = data.get('contacts', {})
# поиск по login, fio, display_name (регистронезависимо)
query = 'запрос'.lower()
hits = {k: v for k, v in contacts.items()
        if query in k.lower() or query in v.get('fio','').lower() or query in v.get('display_name','').lower()}
```
3. Одно совпадение → это человек.
4. Несколько совпадений → уточнить у пользователя.
5. Нет совпадений → сообщить, не угадывать.

## Adding a New Contact

Append a single `|`-delimited row via `patch`. Never rewrite the whole file.

**tutu-contacts row format:**
```
| login | ФИО | aliases | telegram | email | подразделение | команда | должность |
```

**external-contacts row format:**
```
| ФИО | aliases | telegram | email | компания | заметки |
```

The `aliases` field: comma-separated list of ALL known name variants — short name, full name, login, document pseudonym. The richer this field, the better future resolution works.

## Exchange GAL и Zulip как источники (обновлено 28 мая 2026)

`contacts.enc` объединяет два источника:
- **Exchange GAL** — ФИО, email, должность, отдел (`sources.exchange`)
- **Zulip** — email, zulip_id, telegram (`sources.zulip`)

Первичный ключ — `login` (локальная часть email до @). Один логин = один человек, даже если email в Exchange и Zulip разные (например `sereda@tutu.ru` и `sereda@tutu.tech`).

## Три состояния резолвера (зафиксировано 22 мая 2026)

| Состояние | Условие | Действие |
|---|---|---|
| `resolved` | Точное совпадение с `canonical_name`/`aliases` ИЛИ email совпал с GAL | Матчим, пишем |
| `ambiguous` | Низкая уверенность | Суффикс `(?)` в файле, например `ML платформа ТУТУ (?)` — сигнал для ручного ревью в Obsidian |
| `unknown` | Нет совпадений | Оставляем сырым текстом, не трогаем |

**Главное правило: не угадывать.** Лучше пропустить чем соврать.
Реестр aliases пополняется вручную — процент авторезолва растёт сам.

## Особенности резолвинга проектов

- Ключ проекта: `canonical_name` + список `aliases` в файле проекта
- За 5 лет в ТУТУ не повторилось ни одного проекта — коллизии маловероятны
- Исключение: один термин = разные сущности ("АБ платформа" = старая ТУТУ ИЛИ Trisigma) → `ambiguous (?)`
- Пользователь маркирует встречи проектами — это помогает резолверу

## Pitfalls

- Do not use `terminal` + `grep` for search — use `search_files` to avoid shell quoting issues with Cyrillic.
- Aliases field should cover every variant the user might say, including typos in common use.
- One person = one row. Never duplicate.
- When adding aliases to an existing contact, use `patch` to extend the `aliases` cell, not add a new row.
- **Не угадывать ambiguous сущности** — помечать `(?)` и оставлять пользователю. Публикация в Jira/Confluence только после подтверждения пользователем.
