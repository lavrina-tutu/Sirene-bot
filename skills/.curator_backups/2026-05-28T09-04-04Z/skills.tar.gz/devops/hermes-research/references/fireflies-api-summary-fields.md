# Fireflies API — карта полей summary (исследовано 27.05.2026)

## Встреча для проверки
ID: `01KSJ49AGHYFJTRARWAD088Q7N` (Синк AI - МА система)
URL: https://app.fireflies.ai/view/-AI-MA-::01KSJ49AGHYFJTRARWAD088Q7N

## Полный список полей типа Summary (GraphQL introspection)

| Поле | Тип | Заполнено? | FF UI блок |
|------|-----|------------|------------|
| `overview` | String | ✅ | Bullet points (вверху) |
| `short_summary` | String | ✅ | — |
| `gist` | String | ✅ | — |
| `bullet_gist` | String | ✅ | — (с эмодзи) |
| `shorthand_bullet` | String | ✅ | — (таймлайн по фазам) |
| `outline` | String | ❌ всегда null | — |
| `action_items` | String | ✅ | Action items |
| `keywords` | List | ✅ | Keywords |
| `notes` | String | ✅ | **Notes** (основной нарратив ~6KB) |
| `short_overview` | String | ❌ null | — |
| `meeting_type` | String | ❌ null | — |
| `topics_discussed` | — | ❌ null | — |
| `transcript_chapters` | — | ❌ null | — |
| `extended_sections` | List | ✅ | Blockers/Questions/Outline/Topics |

## extended_sections — стабильная структура (4 секции)

```
[Blockers]      — блокеры с деталями и таймкодами
[Questions]     — открытые вопросы
[Meeting Outline] — темы встречи с таймкодами
[Topics]        — топики с таймкодами
```

Форма: `{ title: String, content: String }` — поле `content` содержит готовый текст.
НЕ `items` — реальный API возвращает `content`, не `items`.

## apps_preview.outputs — кастомные скиллы (2 выхода стабильно)

| title | Что содержит |
|-------|-------------|
| `1:1` | Gist + Key Topics + Takeaways + Action Items + Decisions + Meeting Info |
| `Meeting Summary Generator` | Список участников + Обсудили + Блокеры + Задачи по ответственным |

В FF UI: `1:1` отображается как отдельный синий блок, `Meeting Summary Generator` — жёлтый блок Custom Skill.

## GraphQL запрос для полного summary

```graphql
query($id: String!) {
  transcript(id: $id) {
    id title date
    summary {
      overview
      short_summary
      gist
      notes
      action_items
      keywords
      extended_sections { title content }
    }
    apps_preview {
      outputs { app_id title response created_at }
    }
  }
}
```

## Маппинг для MoveFromFF (согласовано с Сашей)

| Секция в summary.md | API поле |
|--------------------|----------|
| Bullet points | `summary.overview` |
| Notes | `summary.notes` |
| Action items | `summary.action_items` |
| Blockers | `extended_sections[title="Blockers"].content` |
| Questions | `extended_sections[title="Questions"].content` |
| Meeting Outline | `extended_sections[title="Meeting Outline"].content` |
| Topics | `extended_sections[title="Topics"].content` |
| Keywords | `summary.keywords` |
